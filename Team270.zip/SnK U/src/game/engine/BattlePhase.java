package game.engine;

public enum BattlePhase
{
	EARLY, INTENSE, GRUMBLING
}
