package game.gui;
import java.beans.EventHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.PriorityQueue;

import game.engine.*;
import game.engine.exceptions.InsufficientResourcesException;
import game.engine.exceptions.InvalidLaneException;
import game.engine.lanes.Lane;
import game.engine.titans.AbnormalTitan;
import game.engine.titans.ArmoredTitan;
import game.engine.titans.ColossalTitan;
import game.engine.titans.Titan;
import game.engine.weapons.Weapon;
import game.engine.weapons.WeaponRegistry;
import game.engine.weapons.factory.WeaponFactory;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class BattleGui2 extends Application {
    private Battle battle;
    private BattleView battleView;
    private ComboBox<String> gameModeComboBox;

    private Label scoreLabel;
    private Label turnLabel;
    private Label phaseLabel;
    private Label resourcesLabel;
    private Label lanesLabel;
    
    
    
    //////this is///////////
   
    int []array1= { 1, 1, 1, 2, 1, 3, 4 };
    int []array2= { 2, 2, 2, 1, 3, 3, 4 };
    int []array3=  { 4, 4, 4, 4, 4, 4, 4 };
    int arrayIndex1=0;
    int arrayIndex2=0;
    int arrayIndex3=0;
    
    ///////////////////////
    
    
    
    ////////initial values////////
	 int score=0;
	 int numberOfTurns=1;
	 String gameMode;
	 int initialnumberOfLanes;
	 int initialResourcesPerLane;
	 //////////////////////
	 
	 
	 
	 ////////lanes info/////////
	  private Lane[] lanesReferences;
	  private int[] lanesWallHealth;
	  private int[] lanesDangerLevels;
	  private int[] lanesActiveTitans;
	  private HashMap<Integer, ArrayList<String>> WeaponsOfEachLanehashMap = new HashMap<>();
	  private HashMap<Integer, ArrayList<VBox>> hashMap1 = new HashMap<>();
//	  private HashMap<Integer, ArrayList<Circle>> hashMap1 = new HashMap<>();
//	  private HashMap<Integer, ArrayList<Integer>> hashMap2 = new HashMap<>();
//	  private HashMap<Integer, ArrayList<Integer>> hashMap2 = new HashMap<>();
	 ////////////////////
	 
	 
	 
	 ///////variables///////
	 int selectedWeapon=0;
	 Lane selectedLane=null;
//	 private HashMap<Integer, ArrayList<Circle>> hashMap1 = new HashMap<>();
	 
	 
	 //////////////
	 
	 
    public void start(Stage primaryStage) throws Exception {
    	 battleView= new BattleView();
		 BorderPane root =battleView.placeUIComponents();
		 root.setStyle("-fx-background-color: lightgray;"); 
         VBox startBox = new VBox(30);
         startBox.setAlignment(Pos.CENTER);
         
          /////////////Titans Images
         Image PureTitanImage = new Image ("PureTitan.png");
         ImageView PureTitanImageView=new ImageView(PureTitanImage);
         Image ArmoredTitanImage = new Image ("ArmoredTitan.png");
         ImageView ArmoredTitanImageView=new ImageView(ArmoredTitanImage);
          /////////////end of titanes images
         
        // Title label
        Label titleLabel = new Label("Welcome to Attack on Titan");
        titleLabel.setFont(Font.font("Arial", 40)); 
        startBox.getChildren().add(titleLabel);

        // Create ComboBox to select game mode
        gameModeComboBox = new ComboBox<>();
        gameModeComboBox.setPromptText("Select game mode");
        gameModeComboBox.setStyle("-fx-font-size: 16px;"); 
        gameModeComboBox.getItems().addAll("Easy", "Hard");
        startBox.getChildren().add(gameModeComboBox);

        // Create Start Game button
        Button startGameButton = new Button("Start!");
        startGameButton.setStyle("-fx-font-size: 16px;");
        startBox.getChildren().add(startGameButton);

        // Event handler for Start Game button
        startGameButton.setOnAction(event -> {
            String selectedGameMode = gameModeComboBox.getValue();
            if (selectedGameMode != null) {
                // Set the selected game mode
               gameMode=selectedGameMode;
               if(gameMode=="Easy"){
            	   initialnumberOfLanes=3;
            	   initialResourcesPerLane=250;
            	   this.lanesReferences = new Lane[3];//remove this line if its corrupt
            	   this.lanesWallHealth = new int[3];//remove this line if its corrupt
            	   this.lanesDangerLevels=new int[3];//remove this line if its corrupt
            	   this.lanesActiveTitans=new int[3];//remove this line if its corrupt
            	   for (int i = 0; i < 3; i++) {
                       ArrayList<VBox> vBoxList = new ArrayList<>();
                       for (int j = 0; j < 10; j++) {
                           VBox vbox = new VBox();
                           vbox.setPrefWidth(200);
                           vbox.setPrefHeight(100);
                           vBoxList.add(vbox);
                       }
                       hashMap1.put(i, vBoxList);
                   }
            	 
//            	   this.weaponsInLane=new int [3];
               }else{
            	   initialnumberOfLanes=5;
            	   initialResourcesPerLane=125;
            	   this.lanesReferences = new Lane[5];//remove this line if its corrupt
            	   this.lanesWallHealth = new int[5];//remove this line if its corrupt
            	   this.lanesDangerLevels=new int[5];//remove this line if its corrupt
            	   this.lanesActiveTitans=new int[5];//remove this line if its corrupt
            	   for (int i = 0; i < 5; i++) {
                       ArrayList<VBox> vBoxList = new ArrayList<>();
                       for (int j = 0; j < 10; j++) {
                           VBox vbox = new VBox();
                           vbox.setPrefWidth(200);
                           vbox.setPrefHeight(100);
                           vBoxList.add(vbox);
                       }
                       hashMap1.put(i, vBoxList);
                   }
            	
//            	   this.weaponsInLane=new int [5];
               }
               
               
               
               
               root.setStyle("-fx-background-color: white;"); // Set background color for visualization
                // Remove both the ComboBox and the Start Game button from the layout
            	startBox.getChildren().removeAll(gameModeComboBox, startGameButton,titleLabel );
            	  displayInstructions("Welcome to Attack on Titan !",
                          "Endless tower game where you have to protect walls of the lanes from titans at all cost. \nIf all walls are destroyed, you lose.");
            	// Create a GridPane to display game information
                  GridPane infoGrid = new GridPane();
                  infoGrid.setAlignment(Pos.CENTER);
                  infoGrid.setHgap(10);
                  infoGrid.setVgap(10);
                  infoGrid.setStyle("-fx-padding: 10px;");
                  
                  // Labels for game information
                  scoreLabel = new Label("Score: " + score);
                  turnLabel = new Label("Turn: " + numberOfTurns);
                  phaseLabel = new Label("Phase: ");
                  resourcesLabel = new Label("Resources: ");
                  lanesLabel=new Label("Lanes Left:" + initialnumberOfLanes);
                  
                  // Add labels to the grid
                  infoGrid.add(scoreLabel, 0, 0);
                  infoGrid.add(turnLabel, 1, 0);
                  infoGrid.add(phaseLabel, 2, 0);
                  infoGrid.add(resourcesLabel, 3, 0);
                  infoGrid.add(lanesLabel,4,0);
                  
                  // Add infoGrid to the top of the BorderPane
                  root.setTop(infoGrid);
            	  try {
                      battle = new Battle(0, 0, 3, initialnumberOfLanes, initialResourcesPerLane);
                      // Update the game information labels
                      updateGameInfo();
                      
                  } catch (Exception e) {
                      e.printStackTrace();
                  } 
            	  
            	  //////////////////////weaponshop/////////////////////////////////////////////////
            	  
            	  GridPane weaponShopGrid = new GridPane();
            	  WeaponFactory weaponShop = battle.getWeaponFactory();

                  // Retrieve the weapon shop map
                  HashMap<Integer, WeaponRegistry> weaponShopMap = weaponShop.getWeaponShop();

                  // Loop over the weaponShop map and print weapon code and price
                  int index = 0;
                  VBox[] selectedWeaponBox = {null}; // Array to hold the selected VBox
                  
//                  ToggleGroup weaponToggleGroup = new ToggleGroup(); 
               
                  
                  for (WeaponRegistry weaponRegistry : weaponShopMap.values()) {
                      int weaponCode = weaponRegistry.getCode();
                      int weaponPrice = weaponRegistry.getPrice();
                      int weaponDamage=weaponRegistry.getDamage();
                      String weaponType=null;
                      String weaponName=weaponRegistry.getName();
                      VBox weaponShopSingleItem = new VBox();
//                      Button tmp=new Button("test"+weaponCode);
                     
                     weaponShopSingleItem.setStyle("-fx-border-color: black; -fx-border-width: 1px; -fx-spacing: 10px;");
                    
                   
                     weaponShopSingleItem.setOnMouseClicked(event2 -> {
                        // Deselect the previously selected VBox
                         if (selectedWeaponBox[0] != null) {
                              selectedWeaponBox[0].setStyle("-fx-border-color: black; -fx-border-width: 1px; -fx-spacing: 10px;");
                         }

                        // Select the clicked VBox
                         weaponShopSingleItem.setStyle("-fx-border-color: blue; -fx-border-width: 1px; -fx-spacing: 10px;");                       
                         
                              
                          // Update the selected VBox
                         selectedWeaponBox[0] = weaponShopSingleItem;
                         selectedWeapon= weaponCode;
                          // Perform other actions here, such as storing the selected weapon or updating UI
                          // ...
                    });
                 
               
            
                      
                      switch(weaponCode){
                      case 1:
                    	  weaponType="Piercing Cannon";
                    	  break;
                      case 2:
                    	  weaponType="Sniper Cannon";
                    	  break;
                      case 3:
                    	  weaponType="VolleySpread Cannon";
                    	  break;
                      case 4:
                    	  weaponType="WallTrap";
                    	  break;
                    	 default:
                    		 weaponType="No Type"; 
                      }
                      
//                      Button buyBtn=new Button(" Buy");
                      Label priceLabel=new Label(" Price : "+weaponPrice);
                      Label damageLabel=new Label(" Damage : "+weaponDamage);
                      Label nameLabel=new Label(" Name : "+weaponName);
                      Label typeLabel=new Label(" Type : "+weaponType);
                      
                      
                      weaponShopSingleItem.getChildren().addAll(nameLabel,typeLabel,priceLabel,damageLabel);
                      weaponShopGrid.add(weaponShopSingleItem,index,0);
//                      weaponShopGrid.add(weaponRadioButton,index,0);
                      
                     index++; 
                     
                  }
                 
                  root.setLeft(weaponShopGrid);
    
                  
                  ////////////////////Buy and pass buttons///////////////////////////////////////////////////
                  Button buySelectedWeapon=new Button("Buy");
                  Button passTurn=new Button("Pass Turn");
                  weaponShopGrid.add(buySelectedWeapon, 1, 1);
                  weaponShopGrid.add(passTurn, 2, 1);


                  passTurn.setOnMouseClicked(passPurchaseEvent -> {
                	  
                	    try {
                	        if (!battle.isGameOver()) {
                	        	battle.passTurn();
                	            updateGameInfo();
                	            root.setBottom(updateLanesInfo());
                	            root.setCenter(updateGameInfo2());
                	        } else {
                	            // Handle game over logic here, for example:
                	            // switchToGameOverScene();
                	            System.out.println("Game over. Switch to the game over scene.");
                	            primaryStage.setScene(createGameOverScene(primaryStage));
                	        }
                	    }  catch (Exception e) {
                	        // Handle any other unexpected exceptions
                	    	displaySelectValidOrNot("unexpected error","error");
                	    	 System.out.println("An unexpected error occurred: " + e.getMessage());
                	        e.printStackTrace(); // Optionally print the stack trace for debugging
                	    }
                	});
                  
                  
                buySelectedWeapon.setOnMouseClicked(BuyWeaponEvent ->{
                	 if (selectedWeapon == 0 || selectedLane == null) {
                	        // Handle the case where selectedWeapon is 0 or selectedLane is null
                	        // For example, display an error message to the user
                		 displaySelectValidOrNot("Invalid selection","Please choose a weapon and a lane.");
                	        System.err.println("Invalid selection: Please choose a weapon and a lane.");
                	    } else {
                	        // Proceed with the logic for purchasing the weapon
                	        // For example:
                	        try {
                	            // Call a method to handle the weapon purchase
                	        	if (!battle.isGameOver()) {
                	        		 battle.purchaseWeapon(selectedWeapon, selectedLane);
                	        		 getLanesIndexToAddWeapon();
                     	            updateGameInfo();
                     	           root.setBottom(updateLanesInfo());
                     	           root.setCenter(updateGameInfo2());
                     	            selectedLane=null;
                    	        }else{
                    	        	  System.out.println("Game over. Switch to the game over scene.");
                      	            primaryStage.setScene(createGameOverScene(primaryStage));
                    	        }
                	           
                	        } catch (InsufficientResourcesException e) {
                	            // Handle the case where there are insufficient resources
                	            // For example, display an error message to the user
                	        	displaySelectValidOrNot("Insufficient resources","Unable to purchase the selected weapon");
                	            System.err.println("Insufficient resources: Unable to purchase the selected weapon.");
                	        } catch (InvalidLaneException e) {
                	            // Handle the case where the selected lane is invalid
                	            // For example, display an error message to the user

                	        	displaySelectValidOrNot("Invalid lane:","Please choose a valid lane.");
                	            System.err.println("Invalid lane: Please choose a valid lane.");
                	        }
                	    }
                });
                  
                  
                  
            	//////////////////////////end of weapon shop/////////////////////////////////////////////////////      
                                 
                  ///////////////////////lane info////////////////////////////////////
                root.setCenter(updateGameInfo2());
              
                

                  ////////////////////////end of lane info//////////////////////////////////
            	
                
                root.setBottom(updateLanesInfo());
            	
            }
        });
        
        
        
        
        
        
       
        root.setCenter(startBox);
        Scene scene = new Scene(root, 1000, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Attack on Titan");
          Image iconImage =new Image("AOTicon.png");
          primaryStage.getIcons().add(iconImage);
        primaryStage.show();
    }
   
    
    private void updateGameInfo() {
        // Update the game information labels based on the battle state
        scoreLabel.setText("Score: " + battle.getScore());
        turnLabel.setText("Turn: " + battle.getNumberOfTurns());
        phaseLabel.setText("Phase: " + battle.getBattlePhase());
        resourcesLabel.setText("Resources: " + battle.getResourcesGathered());
        lanesLabel.setText("Lanes Left: " + battle.getLanes().size());

    } 
    
    
    private void displayInstructions(String title, String message) {
        Stage alertStage = new Stage();
        alertStage.setTitle(title);

        Label label = new Label(message);
        Button closeButton = new Button("okay");
        closeButton.setOnAction(event -> alertStage.close());

        BorderPane pane = new BorderPane();
        pane.setTop(label);
        pane.setCenter(closeButton);

        Scene scene = new Scene(pane, 500, 100);
        alertStage.setScene(scene);
        alertStage.show();
    }
    
    
    
    
    private void displaySelectValidOrNot(String title, String message) {
        Stage alertStage = new Stage();
        alertStage.setTitle(title);

        Label label = new Label(message);
        Button closeButton = new Button("okay");
        closeButton.setOnAction(event -> alertStage.close());

        BorderPane pane = new BorderPane();
        pane.setTop(label);
        pane.setCenter(closeButton);

        Scene scene = new Scene(pane, 500, 100);
        alertStage.setScene(scene);
        alertStage.show();
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

//    

    
//    private GridPane updateGameInfo2() {
//        GridPane LaneInfoGrid = new GridPane();
//        
//        // Assuming battle.getLanes() returns a PriorityQueue<Lane>
//        PriorityQueue<Lane> theLanes = new PriorityQueue<>(battle.getLanes());
//      
//        VBox[] selectedLaneBox = {null}; // Array to hold the selected VBox
//        int index = 0;
//      
//        while (!theLanes.isEmpty()) {
//            Lane theCurrentLane = theLanes.poll();
//           
//            // Skip lanes with wall health of 0
//            if (theCurrentLane.getLaneWall().getCurrentHealth() == 0) {
//                continue;
//            }
//           
//                 
//            lanesReferences[index] = theCurrentLane;
//            lanesActiveTitans[index] = theCurrentLane.getTitans().size();
//            lanesWallHealth[index] = theCurrentLane.getLaneWall().getCurrentHealth();
//            lanesDangerLevels[index] = theCurrentLane.getDangerLevel();
//
//            VBox laneSingleItem = new VBox();
//            laneSingleItem.setStyle("-fx-border-color: black; -fx-border-width: 1px; -fx-spacing: 10px;");
//            
//            laneSingleItem.setOnMouseClicked(event2 -> {
//                // Deselect the previously selected VBox
//                if (selectedLaneBox[0] != null) {
//                    selectedLaneBox[0].setStyle("-fx-border-color: black; -fx-border-width: 1px; -fx-spacing: 10px;");
//                }
//
//                // Select the clicked VBox
//                laneSingleItem.setStyle("-fx-border-color: blue; -fx-border-width: 1px; -fx-spacing: 10px;");
//
//                // Update the selected VBox
//                selectedLaneBox[0] = laneSingleItem;
//                selectedLane = theCurrentLane;
//                // Perform other actions here, such as storing the selected weapon or updating UI
//                // ...
//            });
//
//            Label laneTitle = new Label("Lane : " + (index + 1));
//            Label wallHealthLabel = new Label("WallHealth : " + lanesWallHealth[index]);
//            Label dangerLevelLabel = new Label("DangerLevel : " + lanesDangerLevels[index]);
//            Label activeTitanLabel = new Label("Active Titans : " + lanesActiveTitans[index]);
//
//            laneSingleItem.getChildren().addAll(laneTitle, wallHealthLabel, dangerLevelLabel, activeTitanLabel);
//            LaneInfoGrid.add(laneSingleItem, index, 0);
//            index++;
//        }
//
//       
//        return LaneInfoGrid;
//    }

    private GridPane updateGameInfo2() {
        GridPane LaneInfoGrid = new GridPane();

        ArrayList<Lane> theLanes = battle.getOriginalLanes(); // Assuming battle.getOriginalLanes() returns an ArrayList<Lane>
      
        VBox[] selectedLaneBox = {null}; // Array to hold the selected VBox
        int index = 0;
      
        for (Lane theCurrentLane : theLanes) {
            // Skip lanes with wall health of 0
            if (theCurrentLane.getLaneWall().getCurrentHealth() == 0) {
                continue;
            }
           
                 
            lanesReferences[index] = theCurrentLane;
            lanesActiveTitans[index] = theCurrentLane.getTitans().size();
            lanesWallHealth[index] = theCurrentLane.getLaneWall().getCurrentHealth();
            lanesDangerLevels[index] = theCurrentLane.getDangerLevel();

            VBox laneSingleItem = new VBox();
            laneSingleItem.setStyle("-fx-border-color: black; -fx-border-width: 1px; -fx-spacing: 10px;");
            
            laneSingleItem.setOnMouseClicked(event2 -> {
                // Deselect the previously selected VBox
                if (selectedLaneBox[0] != null) {
                    selectedLaneBox[0].setStyle("-fx-border-color: black; -fx-border-width: 1px; -fx-spacing: 10px;");
                }

                // Select the clicked VBox
                laneSingleItem.setStyle("-fx-border-color: blue; -fx-border-width: 1px; -fx-spacing: 10px;");

                // Update the selected VBox
                selectedLaneBox[0] = laneSingleItem;
                selectedLane = theCurrentLane;
                // Perform other actions here, such as storing the selected weapon or updating UI
                // ...
            });

            Label laneTitle = new Label("Lane : " + (index + 1));
            Label wallHealthLabel = new Label("WallHealth : " + lanesWallHealth[index]);
            Label dangerLevelLabel = new Label("DangerLevel : " + lanesDangerLevels[index]);
            Label activeTitanLabel = new Label("Active Titans : " + lanesActiveTitans[index]);

            laneSingleItem.getChildren().addAll(laneTitle, wallHealthLabel, dangerLevelLabel, activeTitanLabel);
            LaneInfoGrid.add(laneSingleItem, index, 0);
            index++;
        }

       
        return LaneInfoGrid;
    }

    
    /////////////////////////to create a lane/////////
    
  
    
    private BorderPane createLane(int laneIndex,int laneToSpawn) {
        BorderPane lanePane = new BorderPane();
        lanePane.setStyle("-fx-border-color: black; -fx-border-width: 1px; -fx-spacing: 10px;");
        
        // Place to display bought weapon
        
        Label weaponLabel = new Label("Weapon: None");
        weaponLabel.setFont(new Font("Arial", 20));
        
        
        // Loop over the weapons in the HashMap and display them
        StringBuilder weaponsText = new StringBuilder("Weapon(s): ");
        ArrayList<String> weapons = WeaponsOfEachLanehashMap.get(laneIndex);
        if (weapons != null && !weapons.isEmpty()) {
        	
            for (int i=0;i<weapons.size();i++) {
                weaponsText.append(weapons.get(i)).append(", ");
            }
            // Remove the trailing comma and space
            weaponsText.delete(weaponsText.length() - 2, weaponsText.length());
            weaponLabel.setText(weaponsText.toString());
        }
        
       
         
        
        
        lanePane.setTop(weaponLabel);
        BorderPane.setAlignment(weaponLabel, Pos.CENTER);

        // Place to display the lane where titans will move
//        boolean putTheTitanInThatLane=false;
     
        if(laneIndex==laneToSpawn){
        	   ArrayList<VBox> tmppp=hashMap1.get(laneIndex);
        	   VBox tmppp2=tmppp.get(0);
        	   Circle x=new Circle(40,Color.RED);
        	  
     
        	  int theIndex=0;
        	   switch(phaseLabel.getText()){
        	   case "EARLY":
        		   theIndex=0;
        		   break;
        	   case "INTENSE":
        		   theIndex=1;
        		   break;
        	   case "GRUMBLING":
        		   theIndex=2;
        		   break;
        		   
        	   }
        	   
        	  
        	  if(theIndex==0){
        		  if(arrayIndex1>array1.length-1){
        			  arrayIndex1=0;
        		  }
           	   switch(array1[arrayIndex1]){
           	   case 1:
           		   x= new Circle(40,Color.RED);
           		   break;
           	   case 2:
           		   x= new Circle(40,Color.BLUE);
           		   break;
           	   case 3:
           		   x= new Circle(80,Color.GREEN);
           		   break;
           	   case 4:
           		  x=new Circle(40,Color.YELLOW);
           		  break;
           		  default:
           	 x= new Circle(40,Color.RED);
           	   }
           	arrayIndex1++;
        	  }else if(theIndex==1){
        		  if(arrayIndex2>array2.length-1){
        			  arrayIndex2=0;
        		  }
           	   switch(array2[arrayIndex2]){
           	   case 1:
           		   x= new Circle(40,Color.RED);
           		   break;
           	   case 2:
           		   x= new Circle(40,Color.BLUE);
           		   break;
           	   case 3:
           		   x= new Circle(80,Color.GREEN);
           		   break;
           	   case 4:
           		  x=new Circle(40,Color.YELLOW);
           		  break;
           		  default:
           	 x= new Circle(40,Color.RED);
           	   }
           	arrayIndex2++;
        	  }else{
        		  if(arrayIndex3>array3.length-1){
        			  arrayIndex3=0;
        		  }
           	   switch(array3[arrayIndex3]){
           	   case 1:
           		   x= new Circle(40,Color.RED);
           		   break;
           	   case 2:
           		   x= new Circle(40,Color.BLUE);
           		   break;
           	   case 3:
           		   x= new Circle(80,Color.GREEN);
           		   break;
           	   case 4:
           		  x=new Circle(40,Color.YELLOW);
           		  break;
           		  default:
           	 x= new Circle(40,Color.RED);
           	   }
           	arrayIndex3++;
        	  }
        	   

        	   
     	     
               
         	
        	 tmppp2.getChildren().add(x);
        
        	
        	
             	
        }
        GridPane laneGridPane = createLaneGridPane(laneIndex);
        lanePane.setCenter(laneGridPane);

        return lanePane;
    }

    
    
    
//    private GridPane createLaneGridPane(int laneIndex) {
//        GridPane laneGridPane = new GridPane();
//        laneGridPane.setStyle("-fx-border-color: black; -fx-border-width: 1px; -fx-spacing: 1000px;");
//        
//        ArrayList<Circle>ttt= hashMap1.get(laneIndex);
//    	ArrayList<Integer>fff=hashMap2.get(laneIndex);
//     	ArrayList<Integer>tmp1=new ArrayList<Integer>();
//    	
//	    for(int i=0;i<fff.size();i++){
//	    	tmp1.add(fff.get(i)+1);
//	    }
//	    
//        
//    	for (int j = 0; j <10; j++) {
//    	    StackPane box = createBox();
//    	    for(int k=0;k<tmp1.size();k++){
//    	    	     if(tmp1.get(k)==j){
//    	    	    	 box.getChildren().add(ttt.get(k));
//    	    	     }
//    	    }
//    	    laneGridPane.add(box, j, 0);
//    	}
//    	
//    	
//
//        
//        return laneGridPane;
//    }
//    
//    
//    private StackPane createBox() {
//        StackPane box = new StackPane();
//        box.setPrefSize(200, 200); // Adjust size as needed
//        box.setStyle("-fx-border-color: black; -fx-border-width: 1px;");
//        return box;
//    }
    
    
    private GridPane createLaneGridPane(int laneIndex) {
    	   GridPane laneGridPane = new GridPane();
         laneGridPane.setStyle("-fx-border-color: black; -fx-border-width: 1px; -fx-spacing: 1000px;");
        
         HBox box=createBox();
         ArrayList<VBox> yyyy=hashMap1.get(laneIndex);
         
     	for(int i=0;i<10;i++){
     		yyyy.get(i).setStyle("-fx-border-color: black; -fx-border-width: 1px;");
     		box.getChildren().add(yyyy.get(i));
     	}
     	
     	for (int j = 9; j >0; j--) {
     	    // Clear the children of the target VBox
     		
     	    yyyy.get(j).getChildren().clear();

     	    // Get the children of the source VBox
     	    ObservableList<Node> children = yyyy.get(j - 1).getChildren();

     	    // Add the children to the target VBox
     	    yyyy.get(j).getChildren().addAll(children);
     	}
     	// Clear the children of the first VBox
     	yyyy.get(0).getChildren().clear();
     	
     	
     	
        laneGridPane.add(box,0,laneIndex);
         
         return laneGridPane;
    }
    
    
     
    private   HBox createBox() {
    	HBox box = new HBox();
         box.setPrefWidth(2000);
         box.setPrefHeight(100);
        box.setStyle("-fx-border-color: black; -fx-border-width: 1px;");
        return box;
    }
    


 //////////////end of to create lane///////////
   
    
    private Scene createGameOverScene(Stage primaryStage) {
        VBox gameOverBox = new VBox(20);
        gameOverBox.setAlignment(Pos.CENTER);
        
        Label gameOverLabel = new Label("Game Over");
        gameOverLabel.setFont(Font.font("Arial", 40));
        
        Button restartButton = new Button("Restart");
        restartButton.setFont(Font.font("Arial", 20));
        restartButton.setOnAction(event -> {
            // Call the start method to restart the game
            try {
                start(primaryStage);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        
        gameOverBox.getChildren().addAll(gameOverLabel, restartButton);
        return new Scene(gameOverBox, 1000, 600);
    }

    
    private void getLanesIndexToAddWeapon(){
    	ArrayList<Lane> tempQueue = new ArrayList<>(battle.getOriginalLanes());
    	   int index = 0;
    	for (Lane lane : tempQueue) {
    	    if (lane.equals(selectedLane)) {
    	    	// First, get the ArrayList corresponding to the index
    	    	ArrayList<String> weaponsList = WeaponsOfEachLanehashMap.get(index);

    	    	// If the ArrayList doesn't exist, create a new one
    	    	if (weaponsList == null) {
    	    	    weaponsList = new ArrayList<>();
    	    	    WeaponsOfEachLanehashMap.put(index, weaponsList);
    	    	}

    	    	// Now, add the selectedWeapon to the ArrayList
    	    	
    	    	
    	    	String tmpName="";
    	    	switch(selectedWeapon){
    	    	case 1:
    	    		tmpName="AntiTitanShell";
    	    		break;
    	    	case 2:
    	    		tmpName="LongRangeSpear";
    	    		break;
    	    	case 3:
    	    		tmpName="WallSpreadCanon";
    	    		break;
    	    	case 4:
    	    		tmpName="ProximityTrap";
    	    		break;
    	    		default:
    	    			tmpName="None";
    	    	}
    	    	
    	    	
    	    	
    	    	
    	    	weaponsList.add(tmpName);
    	    	}
    	    	
    	    index++; // Move the index increment inside the loop
    	    }
    	
   
}
    
    private  GridPane updateLanesInfo(){
    	 
        GridPane game = new GridPane();

        for (int i = 0; i < initialnumberOfLanes; i++) {
        	int LaneNumber=0;
        	for(int j=0;j<battle.getOriginalLanes().size();j++){
        		if(!battle.getOriginalLanes().get(j).isLaneLost() && battle.getOriginalLanes().get(j).getDangerLevel()==battle.getLanes().peek().getDangerLevel()){
        			LaneNumber=j;
        			break;
        		}
        		
        	}
        	
        	
            game.add(createLane(i,LaneNumber), 0, i);
        }
        
    
        
       return game;
    }
   



   

    public static void main(String[] args) {
        launch(args);
    }
}

