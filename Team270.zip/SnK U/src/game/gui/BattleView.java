package game.gui;

import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;


public class BattleView {

	 private BorderPane borderPane;
	 
	 
	 public BattleView() {
		 borderPane=new BorderPane();
		 
		 
		 
		 
		 
	    }
	 
	 
	 public BorderPane placeUIComponents(){
	    	return borderPane;
	    }
	 
	 
	 
	 
	 
	 
}
